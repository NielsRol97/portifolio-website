<script lang="ts" setup>
import { usePortfolioData } from '@/composables/usePortfolioData'
import HeroSection from '@/components/sections/HeroSection.vue'
import ServicesSection from '@/components/sections/ServicesSection.vue'
import ProjectsSection from '@/components/sections/ProjectsSection.vue'
import ProcessSection from '@/components/sections/ProcessSection.vue'
import AboutSection from '@/components/sections/AboutSection.vue'
import StackSection from '@/components/sections/StackSection.vue'
import ContactSection from '@/components/sections/ContactSection.vue'
const { profile } = usePortfolioData()
useSeoMeta({
  title: `${profile.name} · ${profile.role}`,
  description:
    'Developer portfolio website in het Nederlands, gebouwd met Nuxt en Tailwind. Gericht op performance, positionering en onderhoudbare code.',
  ogTitle: `${profile.name} · ${profile.role}`,
  ogDescription:
    'Moderne portfolio website voor developers en technische freelancers. Snel, strak en gebouwd op een schaalbare basis.',
  twitterCard: 'summary_large_image',
})
</script>

<template>
  <div>
    <HeroSection />
    <ServicesSection />
    <ProjectsSection />
    <ProcessSection />
    <AboutSection />
    <StackSection />
    <ContactSection />
  </div>
</template>
