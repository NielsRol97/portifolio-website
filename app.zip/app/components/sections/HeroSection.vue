<script lang="ts" setup>
const { hero, stats, profile } = usePortfolioData()

import PrimaryButton from '@/components/ui/PrimaryButton.vue'
import StatCard from '@/components/ui/StatCard.vue'
</script>

<template>
  <section id="home" class="px-6 pb-20 pt-16 lg:px-8 lg:pb-28 lg:pt-24">
    <div class="mx-auto grid max-w-7xl items-center gap-12 lg:grid-cols-[1.05fr_0.95fr] lg:gap-16">
      <div>
        <span class="inline-flex rounded-full border border-cyan-300/20 bg-cyan-400/10 px-4 py-2 text-xs font-semibold uppercase tracking-[0.24em] text-cyan-200 shadow-[0_10px_30px_rgba(34,211,238,.12)]">
          {{ hero.badge }}
        </span>

        <h1 class="mt-6 max-w-4xl text-4xl font-black tracking-tight text-white sm:text-5xl lg:text-7xl lg:leading-[1.03]">
          <span class="text-gradient">{{ hero.title }}</span>
        </h1>

        <p class="mt-6 max-w-2xl text-lg leading-8 text-slate-300">
          {{ hero.intro }}
        </p>

        <div class="mt-8 flex flex-col gap-4 sm:flex-row">
          <PrimaryButton :href="hero.primaryCta.href">
            {{ hero.primaryCta.label }}
          </PrimaryButton>
          <PrimaryButton :href="hero.secondaryCta.href" variant="ghost">
            {{ hero.secondaryCta.label }}
          </PrimaryButton>
        </div>

        <div class="mt-10 flex flex-wrap items-center gap-4 text-sm text-slate-400">
          <span class="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-4 py-2 shadow-[inset_0_1px_0_rgba(255,255,255,.04)]">
            <span class="h-2.5 w-2.5 rounded-full bg-emerald-400 shadow-[0_0_14px_rgba(74,222,128,.7)]" />
            Open voor projecten en samenwerkingen
          </span>
          <span class="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-4 py-2 shadow-[inset_0_1px_0_rgba(255,255,255,.04)]">
            {{ profile.location }}
          </span>
        </div>
      </div>

      <div class="relative">
        <div class="absolute -left-8 -top-8 h-40 w-40 rounded-full bg-cyan-400/12 blur-3xl" />
        <div class="absolute -bottom-10 right-0 h-52 w-52 rounded-full bg-indigo-400/12 blur-3xl" />

        <div class="card-surface glow-ring relative overflow-hidden rounded-4xl p-6 xl:p-8">
          <div class="flex flex-wrap items-start justify-between gap-4 border-b border-white/10 pb-5">
            <div>
              <p class="text-sm font-semibold uppercase tracking-[0.24em] text-cyan-300">Profiel</p>
              <p class="mt-2 text-2xl font-bold text-white">{{ profile.name }}</p>
              <p class="mt-2 max-w-lg text-sm leading-6 text-slate-400">
                Gericht op moderne webontwikkeling met duidelijke architectuur, consistente componenten en onderhoudbare code.
              </p>
            </div>
            <div class="rounded-2xl border border-cyan-300/20 bg-cyan-400/10 px-3 py-2 text-sm text-cyan-200 shadow-[inset_0_1px_0_rgba(255,255,255,.05)]">
              {{ profile.role }}
            </div>
          </div>

          <div class="mt-6 grid gap-4 lg:grid-cols-[1.1fr_0.9fr]">
            <div class="rounded-[1.75rem] border border-white/10 bg-slate-950/70 p-5 shadow-[inset_0_1px_0_rgba(255,255,255,.03)]">
              <p class="text-xs uppercase tracking-[0.2em] text-slate-500">Focus</p>
              <p class="mt-3 text-sm leading-7 text-slate-200">
                Laravel, Nuxt en het bouwen van duidelijke webapplicaties met aandacht voor performance, onderhoudbaarheid en een logische opbouw.
              </p>
            </div>

            <div class="rounded-[1.75rem] border border-white/10 bg-white/4 p-5 shadow-[inset_0_1px_0_rgba(255,255,255,.03)]">
              <p class="text-xs uppercase tracking-[0.2em] text-slate-500">Waar ik op let</p>
              <ul class="mt-3 space-y-3 text-sm text-slate-200">
                <li class="flex gap-3"><span class="text-cyan-300">→</span><span>Duidelijke structuur</span></li>
                <li class="flex gap-3"><span class="text-cyan-300">→</span><span>Herbruikbare componenten</span></li>
                <li class="flex gap-3"><span class="text-cyan-300">→</span><span>Performance als basis</span></li>
              </ul>
            </div>
          </div>

          <div class="mt-6 grid gap-4 sm:grid-cols-3">
            <StatCard
              v-for="stat in stats"
              :key="stat.label"
              :value="stat.value"
              :label="stat.label"
              :description="stat.description"
            />
          </div>
        </div>
      </div>
    </div>
  </section>
</template>
